import torchvision.models as models
import torch.nn as nn
import torch

num_classes = 100

class Identity(nn.Module):
  def __init__(self):
    super(Identity, self).__init__()

  def forward(self, x):
    return x

class Model(nn.Module):

  def __init__(self, num_classes):
        super(Model, self).__init__()
        self.model = models.resnet50(pretrained=True)
        self.conv1 = nn.Conv2d(3,64,3,1,1)
        self.maxpool = Identity()
        self.fc = torch.nn.Linear(2048, num_classes)

  def forward(self, x):
        x = self.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.maxpool(x)

        x = self.model.layer1(x)
        x = self.model.layer2(x)
        x = self.model.layer3(x)
        x = self.model.layer4(x)
        x = self.model.avgpool(x)

        x = self.fc(x)

        return x
    

